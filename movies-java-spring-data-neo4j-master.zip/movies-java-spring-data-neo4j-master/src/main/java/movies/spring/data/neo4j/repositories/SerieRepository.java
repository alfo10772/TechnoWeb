package movies.spring.data.neo4j.repositories;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import movies.spring.data.neo4j.domain.Serie;


@RepositoryRestResource(collectionResourceRel = "series", path = "series")
public interface SerieRepository extends Neo4jRepository<Serie, Long> {

	List<Serie> findAll(Sort sort);
	
	Optional<Serie> findById(@Param("id") Long id);
	
	Long deleteByTitle(@Param("title") String title);
}
