package movies.spring.data.neo4j.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import movies.spring.data.neo4j.domain.Note;

@RepositoryRestResource(collectionResourceRel = "notes", path = "notes")
public interface NoteRepository extends Neo4jRepository<Note, Long>{
	
	Optional<Note> findById(@Param("id") Long id);
	
	List<Note> findByAlert(@Param("alert") String alert);
	
	Long deleteById2(@Param("id2") String id2);

}
