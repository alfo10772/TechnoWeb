package movies.spring.data.neo4j.services;

import java.util.*;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.Role;
import movies.spring.data.neo4j.repositories.MovieRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MovieService {

    private final static Logger LOG = LoggerFactory.getLogger(MovieService.class);

	private final MovieRepository movieRepository;
	public MovieService(MovieRepository movieRepository) {
		this.movieRepository = movieRepository;
	}

	private Map<String, Object> toD3Format(Collection<Movie> movies) {
		List<Map<String, Object>> nodes = new ArrayList<>();
		List<Map<String, Object>> rels = new ArrayList<>();
		int i = 0;
		Iterator<Movie> result = movies.iterator();
		while (result.hasNext()) {
			Movie movie = result.next();
			nodes.add(map("title", movie.getTitle(), "label", "movie"));
			int target = i;
			i++;
			for (Role role : movie.getRoles()) {
				Map<String, Object> actor = map("title", role.getPerson().getName(), "label", "actor");
				int source = nodes.indexOf(actor);
				if (source == -1) {
					nodes.add(actor);
					source = i++;
				}
				rels.add(map("source", source, "target", target));
			}
		}
		return map("nodes", nodes, "links", rels);
	}

	private Map<String, Object> map(String key1, Object value1, String key2, Object value2) {
		Map<String, Object> result = new HashMap<String, Object>(2);
		result.put(key1, value1);
		result.put(key2, value2);
		return result;
	}

    @Transactional(readOnly = true)
    public Movie findByTitle(String title) {
        Movie result = movieRepository.findByTitle(title);
        return result;
    }
    
    @Transactional(readOnly = true)
    public Movie findById(Long id) {
        Optional<Movie> result1 = movieRepository.findById(id);
        Movie result=result1.get();
        return result;
    }
    
    @Transactional(readOnly = true)
    public List<Movie> findAll() {
    	List<Movie> result = movieRepository.findAll(sortByTitleAsc());
        return result;
    }
    
    @Transactional(readOnly = true)
    public List<Movie> sortByRateAsc(List<Movie> movies) {
		int longueur = movies.size();
		boolean permut = false;
 
		while(!permut) {
			permut = true;
			for (int i = 0; i < longueur - 1; i++) {
				if ((movies.get(i)).getNoteMovie() < (movies.get(i+1)).getNoteMovie()) {
					Movie movie1=movies.get(i);
					Movie movie2=movies.get(i+1);
					movies.set(i, movie2);
					movies.set(i+1, movie1);
					permut = false;
				}
			}
		}
		return movies;
	}
    


    @Transactional(readOnly = true)
    public List<Movie> findByTitleLike(String title) {
        List<Movie> result = movieRepository.findByTitleLike(title);
        return result;
    }

	@Transactional(readOnly = true)
	public Map<String, Object>  graph(int limit) {
		Collection<Movie> result = movieRepository.graph(limit);
		return toD3Format(result);
	}
	
	@Transactional(readOnly = true)
	public void addMovie(Movie movie) {
		movieRepository.save(movie);
	}
	
	@Transactional(readOnly = true)
	public void deleteMovie(String title) {
		movieRepository.deleteByTitle(title);
	}
	
	private Sort sortByTitleAsc() {
        return new Sort(Sort.Direction.ASC, "title");
    }
	
}
