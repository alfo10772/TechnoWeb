package movies.spring.data.neo4j.config;


import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import movies.spring.data.neo4j.domain.Admin;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.services.AdminService;
import movies.spring.data.neo4j.services.UserService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true,proxyTargetClass=true)
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
	private UserService userService;
	
	@Autowired
	private AdminService adminService;
	
	public SecurityConfig() {
        super();
    }
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder authenticationMgr) throws Exception{
		Collection<User> users = userService.findAll();
		for (User element : users) {
			authenticationMgr.inMemoryAuthentication()
			.withUser(element.getUsername()).password("{noop}"+element.getPassword()).roles("USER");
		}
		Collection<Admin> admins = adminService.findAll();
		for (Admin element : admins) {
			authenticationMgr.inMemoryAuthentication()
			.withUser(element.getAdminname()).password("{noop}"+element.getPassword()).roles("ADMIN");
		}
		
	}
	
	//Authorization
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http
		.authorizeRequests()
			.antMatchers("/css/**", "/picture/**","/bootstrap/**","/js/**", "/contat").permitAll()
			.antMatchers("/").permitAll()
			.antMatchers("/registration").permitAll()
			.antMatchers("/admin/**").hasAnyRole("ADMIN")
			.antMatchers("/user/**").hasAnyRole("USER")
			.anyRequest().authenticated()
            .and()
        .formLogin()
            .loginPage("/login")
            .permitAll()
            .and()
        .logout()
            .permitAll()
            .and()
        .exceptionHandling().accessDeniedPage("/403")
		.and()
		.httpBasic();
	}
	
//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder(11);
//	}
}
