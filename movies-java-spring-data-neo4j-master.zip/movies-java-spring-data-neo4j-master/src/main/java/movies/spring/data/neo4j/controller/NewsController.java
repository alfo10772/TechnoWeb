package movies.spring.data.neo4j.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import movies.spring.data.neo4j.domain.News;
import movies.spring.data.neo4j.services.NewsService;

@Controller
@SessionAttributes("search")
public class NewsController {
	
	@Autowired
	private NewsService newsService;
	
	
	public NewsController(NewsService newsService) {
		this.newsService = newsService;
	}
	
	@GetMapping({"admin/addnews"})
    public String addPage(Model model) {
    	model.addAttribute("news", new News());
    	return "admin/ajout_news";
    }
    
    @PostMapping(value = "/addnews")
    public String add(@ModelAttribute News news, ModelMap model) {
    	model.addAttribute("title", news.getTitle());
        model.addAttribute("content", news.getContent());
        model.addAttribute("picture", news.getPicture());
        model.addAttribute("date", news.getDate());
        model.addAttribute("author", news.getAuthor());
        model.addAttribute("type", news.getType());
        newsService.addNews(news);
		return "admin/result_news";
    }
    
    @GetMapping("admin/deletenews")
    public String deletePage(Model model) {
    	List<News> listeNews = newsService.findAll();
    	model.addAttribute("news2", new News());
    	model.addAttribute("listenews", listeNews);
    	return "admin/delete_news";
    }
    
    @PostMapping(value = "/deletenews")
    public String delete(@ModelAttribute News news2, ModelMap model) {
    	String title = news2.getTitle();
    	System.out.println(title);
        newsService.deleteNews(title);
		return "admin/result_delete_news";
    }

}
