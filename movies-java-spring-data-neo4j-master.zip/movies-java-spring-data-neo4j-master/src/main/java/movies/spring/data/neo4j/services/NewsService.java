package movies.spring.data.neo4j.services;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.News;
import movies.spring.data.neo4j.repositories.NewsRepository;

@Service
public class NewsService {
	
	private final NewsRepository newsRepository;
	public NewsService(NewsRepository newsRepository) {
		this.newsRepository = newsRepository;
	}
	
	 @Transactional(readOnly = true)
	    public List<News> findByType(String type) {
	        List<News> result = newsRepository.findByType(type);
	        return result;
	 }
	 
	 @Transactional(readOnly = true)
	    public List<News> findAll() {
	    	List<News> result = newsRepository.findAll(sortByDateAsc());
	        return result;
	    }
	 
	 private Sort sortByDateAsc() {
	        return new Sort(Sort.Direction.ASC, "date");
	    }
	 
	 @Transactional(readOnly = true)
		public void addNews(News news) {
			newsRepository.save(news);
		}
		
		@Transactional(readOnly = true)
		public void deleteNews(String title) {
			newsRepository.deleteByTitle(title);
		}

}
