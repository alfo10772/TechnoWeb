package movies.spring.data.neo4j.repositories;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import movies.spring.data.neo4j.domain.News;

@RepositoryRestResource(collectionResourceRel = "news", path = "news")
public interface NewsRepository extends Neo4jRepository<News, Long> {
	
	List<News> findByType(@Param("type") String type);
	
	List<News> findAll(Sort sort);
	
	Long deleteByTitle(@Param("title") String title);

}
