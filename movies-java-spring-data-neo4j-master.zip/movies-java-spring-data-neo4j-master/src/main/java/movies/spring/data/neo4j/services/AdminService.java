package movies.spring.data.neo4j.services;

import java.util.Collection;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Admin;
import movies.spring.data.neo4j.repositories.AdminRepository;

@Service
public class AdminService {

	private final AdminRepository adminRepository;
	public AdminService(AdminRepository adminRepository) {
		this.adminRepository = adminRepository;
	}

	@Transactional(readOnly = true)
    public Admin findByAdmin(String adminname) {
        Admin result = adminRepository.findByAdminname(adminname);
        return result;
    }
	
	@Transactional(readOnly = true)
    public Collection<Admin> findAll() {
    	Collection<Admin> result = adminRepository.findAll();
        return result;
    }
	
}
