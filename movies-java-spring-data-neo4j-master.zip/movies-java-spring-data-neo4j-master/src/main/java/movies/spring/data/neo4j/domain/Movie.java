package movies.spring.data.neo4j.domain;

import java.util.ArrayList;
import java.util.List;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import movies.spring.data.neo4j.domain.Note;

@NodeEntity
public class Movie {

	@Id
	@GeneratedValue
	private Long id;
	private String title;
	private int released;
	private String synopsis;
	private String genre;
	private String country;
	private String picture;
	private String trailer;
	

	@JsonIgnoreProperties("movie")
	@Relationship(type = "ACTED_IN", direction = Relationship.INCOMING)
	private List<Role> roles;
	
	@JsonIgnoreProperties("movie")
	@Relationship(type = "NOTE", direction = Relationship.INCOMING)
	private List<Note> notes;

	public Movie() {
	}

	public Movie(String title, int released, String synopsis, String genre, String country, String picture, String trailer) {
		this.title = title;
		this.released = released;
		this.synopsis=synopsis;
		this.genre = genre;
		this.country = country;
		this.picture= picture;
		this.trailer=trailer;
	}

	
	
	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTrailer() {
		return trailer;
	}

	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setReleased(int released) {
		this.released = released;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public int getReleased() {
		return released;
	}

	public String getGenre() {
		return genre;
	}
	
	public String getPicture() {
		return picture;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void addRole(Role role) {
		if (this.roles == null) {
			this.roles = new ArrayList<>();
		}
		this.roles.add(role);
	}
	
	public List<Note> getNotes() {
		return notes;
	}
	
	//effectue la moyenne de toutes les notes du films
	public double getNoteMovie() {
		double somme = 0;
		Double liste=null;
		List<Note> notes2 = notes;
		if (notes2==null) {
			return -1;
		}
		else {
			for(Note note: notes2) {
				liste = note.getNote();
				somme = somme + (double) liste;
			}
			double moyenne = somme / (float) notes2.size();
			return moyenne;
		}
	}
	
	//retourne la note du film par un utilisateur précis
	public double getNoteUser(User user) {
		Double liste=null;
		List<Note> notes2 = notes;
		if (notes2==null) {
			return -1;
		}
		else {
			for(Note note: notes2) {
				User user1 = note.getUser();
				if (user1.getUsername().equals(user.getUsername())) {
					liste = note.getNote();
					return liste;
				}else {}
			}
			return -1;
		}
	}
	
	//retourne le commentaire du film par un utilisateur précis
		public String getCommentUser(Movie movie, User user) {
			String liste=null;
			List<Note> notes = movie.getNotes();
			if (notes==null) {
				return " ";
			}
			else {
				for(Note note: notes) {
					User user1 = note.getUser();
					if (user1.getUsername().equals(user.getUsername())) {
						liste = note.getComment();
						return liste;
					}
				}
				return " ";
			}
		}
	
	//retourne la liste des acteurs du film
	public List<String> getActorMovie(Movie movie){
		List<Role> roles = movie.getRoles();
		List<String> liste=new ArrayList<String>();
		if (roles==null) {
			return null;
		}
		for(Role role: roles) {
			Person actor= role.getPerson();
			String actorname=actor.getName();
			liste.add(actorname);
		}
		return liste;
	}

	public void addNote(Note note) {
		if (this.notes == null) {
			this.notes = new ArrayList<>();
		}
		this.notes.add(note);
	}
}