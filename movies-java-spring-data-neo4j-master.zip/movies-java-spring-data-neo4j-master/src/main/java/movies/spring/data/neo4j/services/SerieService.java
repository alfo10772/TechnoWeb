package movies.spring.data.neo4j.services;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Serie;
import movies.spring.data.neo4j.repositories.SerieRepository;



@Service
public class SerieService {
	
	private final SerieRepository serieRepository;
	public SerieService(SerieRepository serieRepository) {
		this.serieRepository = serieRepository;
	}
	
	@Transactional(readOnly = true)
    public List<Serie> findAll() {
		List<Serie> result = serieRepository.findAll(sortByTitleAsc());
        return result;
    }
	
	@Transactional(readOnly = true)
    public Serie findById(Long id) {
        Optional<Serie> result1 = serieRepository.findById(id);
        Serie result=result1.get();
        return result;
    }
	
	private Sort sortByTitleAsc() {
        return new Sort(Sort.Direction.ASC, "title");
    }
	
	@Transactional(readOnly = true)
	public void addSerie(Serie serie) {
		serieRepository.save(serie);
	}
	
	@Transactional(readOnly = true)
	public void deleteSerie(String title) {
		serieRepository.deleteByTitle(title);
	}
	
	@Transactional(readOnly = true)
    public List<Serie> sortByRateAsc(List<Serie> series) {
		int longueur = series.size();
		boolean permut = false;
 
		while(!permut) {
			permut = true;
			for (int i = 0; i < longueur - 1; i++) {
				if ((series.get(i)).getNoteSerie() < (series.get(i+1)).getNoteSerie()) {
					Serie serie1=series.get(i);
					Serie serie2=series.get(i+1);
					series.set(i, serie2);
					series.set(i+1, serie1);
					permut = false;
				}
			}
		}
		return series;
	}

}
