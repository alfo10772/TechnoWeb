package movies.spring.data.neo4j.services;

import java.util.Collection;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Cinema;
import movies.spring.data.neo4j.domain.Serie;
import movies.spring.data.neo4j.repositories.CinemaRepository;

@Service
public class CinemaService {
	
	private final CinemaRepository cinemaRepository;
	public CinemaService(CinemaRepository cinemaRepository) {
		this.cinemaRepository = cinemaRepository;
	}
	
	@Transactional(readOnly = true)
    public Collection<Cinema> findAll() {
    	Collection<Cinema> result = cinemaRepository.findAll(sortByNameAsc());
        return result;
    }
	
	@Transactional(readOnly = true)
    public Cinema findById(Long id) {
        Optional<Cinema> result1 = cinemaRepository.findById(id);
        Cinema result=result1.get();
        return result;
    }
	
	private Sort sortByNameAsc() {
        return new Sort(Sort.Direction.ASC, "name");
    }
	
	@Transactional(readOnly = true)
	public void addCinema(Cinema cinema) {
		cinemaRepository.save(cinema);
	}
	
	@Transactional(readOnly = true)
	public void deleteCinema(String name) {
		cinemaRepository.deleteByName(name);
	}

}
