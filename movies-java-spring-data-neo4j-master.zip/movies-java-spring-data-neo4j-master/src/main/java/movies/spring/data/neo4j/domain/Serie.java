package movies.spring.data.neo4j.domain;

import java.util.List;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@NodeEntity
public class Serie {
	
	@Id
	@GeneratedValue
	private Long id;
	private String title;
	private int released;
	private String genre;
	private String country;
	private String picture;
	private int nbsaison;

	
	@JsonIgnoreProperties("serie")
	@Relationship(type = "NOTE_S", direction = Relationship.INCOMING)
	private List<Note_S> notes;

	public Serie() {
	}

	public Serie(String title, int released, String genre, String country, String picture, int nbsaison) {
		this.title = title;
		this.released = released;
		this.genre = genre;
		this.country = country;
		this.picture= picture;
		this.nbsaison=nbsaison;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getReleased() {
		return released;
	}

	public void setReleased(int released) {
		this.released = released;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public int getNbsaison() {
		return nbsaison;
	}

	public void setNbsaison(int nbsaison) {
		this.nbsaison = nbsaison;
	}
	
	public List<Note_S> getNotes() {
		return notes;
	}

	public void setNotes(List<Note_S> notes) {
		this.notes = notes;
	}
	
	//effectue la moyenne de toutes les notes de la série
		public double getNoteSerie() {
			double somme = 0;
			Double liste=null;
			List<Note_S> notes2 = notes;
			if (notes2==null) {
				return -1;
			}
			else {
				for(Note_S note: notes2) {
					liste = note.getNote();
					somme = somme + (double) liste;
				}
				double moyenne = somme / (float) notes2.size();
				return moyenne;
			}
		}
		
		//retourne la note de la série par un utilisateur précis
		public double getNoteUser(Serie serie, User user) {
			Double liste=null;
			List<Note_S> notes = serie.getNotes();
			System.out.println(notes);
			if (notes==null) {
				return -1;
			}
			else {
				for(Note_S note: notes) {
					User user1 = note.getUser();
					if (user1.getUsername().equals(user.getUsername())) {
						liste = note.getNote();
						return liste;
					}
				}
				return -1;
			}
		}
		
		//retourne le commentaire de la série par un utilisateur précis
			public String getCommentUser(Serie serie, User user) {
				String liste=null;
				List<Note_S> notes = serie.getNotes();
				if (notes==null) {
					return " ";
				}
				else {
					for(Note_S note: notes) {
						User user1 = note.getUser();
						if (user1.getUsername().equals(user.getUsername())) {
							liste = note.getComment();
							return liste;
						}
					}
					return " ";
				}
			}
}
