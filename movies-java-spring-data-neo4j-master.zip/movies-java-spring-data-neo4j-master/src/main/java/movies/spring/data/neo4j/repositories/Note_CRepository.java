package movies.spring.data.neo4j.repositories;

import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import movies.spring.data.neo4j.domain.Note_C;

@RepositoryRestResource(collectionResourceRel = "notes_c", path = "notes_c")
public interface Note_CRepository extends Neo4jRepository<Note_C, Long> {

}
