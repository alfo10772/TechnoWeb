package movies.spring.data.neo4j.services;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.repositories.UserRepository;

@Service
public class UserService {
	
	private final static Logger LOG = LoggerFactory.getLogger(UserService.class);
	
	private final UserRepository userRepository;
	public UserService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Transactional(readOnly = true)
    public User findByUsername(String username) {
        User result = userRepository.findByUsername(username);
        return result;
    }
	
	@Transactional(readOnly = true)
    public User findByLastname(String lastname) {
        User result = userRepository.findByLastname(lastname);
        return result;
    }
	
	@Transactional(readOnly = true)
    public Collection<User> findAll() {
    	Collection<User> result = userRepository.findAll();
        return result;
    }
	
	@Transactional(readOnly = true)
	public void addUser(User user) {
		userRepository.save(user);
	}
}
