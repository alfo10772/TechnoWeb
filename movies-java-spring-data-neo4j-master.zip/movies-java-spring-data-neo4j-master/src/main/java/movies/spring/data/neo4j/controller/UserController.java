package movies.spring.data.neo4j.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.services.UserService;

@Controller
@SessionAttributes("search")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping(value = "/set_firstname")
    public String setFirstname(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setFirstname(user.getFirstname());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_lastname")
    public String setLastname(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setLastname(user.getLastname());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_address")
    public String setAddress(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setAddress(user.getAddress());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_sex")
    public String setSex(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setSex(user.getSex());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_email")
    public String setEmail(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setEmail(user.getEmail());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_birthdate")
    public String setBirthdate(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setBirthdate(user.getBirthdate());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@PostMapping(value = "/set_picture")
    public String setPicture(@ModelAttribute User user, ModelMap model, HttpServletRequest req, HttpServletResponse resp) {
		String username=req.getUserPrincipal().getName();
    	User user2= userService.findByUsername(username);
    	user2.setPicture(user.getPicture());
    	model.addAttribute("user", user2);
    	userService.addUser(user2);
		return "/information";
	}
	
	@GetMapping("/registration")
    public String registrationPage(Model model) {
		model.addAttribute("user", new User());
        return "inscription";
    }
	
	@PostMapping(value = "/registration")
    public String add(@ModelAttribute User user, ModelMap model) {
    	model.addAttribute("username", user.getUsername());
        model.addAttribute("password", user.getPassword());
        model.addAttribute("address", user.getAddress());
        model.addAttribute("birthdate", user.getBirthdate());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("firstname", user.getFirstname());
        model.addAttribute("lastname", user.getLastname());
        model.addAttribute("sex", user.getSex());
        model.addAttribute("picture", user.getPicture());
        userService.addUser(user);
		return "/result_inscription";
    }

}
