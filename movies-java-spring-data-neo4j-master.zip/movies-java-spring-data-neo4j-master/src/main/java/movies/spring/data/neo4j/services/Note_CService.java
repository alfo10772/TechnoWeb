package movies.spring.data.neo4j.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Note_C;
import movies.spring.data.neo4j.repositories.Note_CRepository;

@Service
public class Note_CService {
	
	private final Note_CRepository note_cRepository;
	public Note_CService(Note_CRepository note_cRepository) {
		this.note_cRepository = note_cRepository;
	}
	
	@Transactional(readOnly = true)
	public void addNote_C(Note_C note) {
		note_cRepository.save(note);
	}

}
