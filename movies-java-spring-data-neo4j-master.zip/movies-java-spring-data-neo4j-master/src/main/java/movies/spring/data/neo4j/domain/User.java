package movies.spring.data.neo4j.domain;

import java.util.List;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@NodeEntity
public class User {
	
	@Id
	@GeneratedValue
	private Long id;
	private String username;
	private String password;
	private String address;
	private String birthdate;
	private String email;
	private String firstname;
	private String lastname;
	private String sex;
	private String picture;
	
	@JsonIgnoreProperties("user")
	@Relationship(type = "NOTE", direction = Relationship.OUTGOING)
	private List<Note> notes;
	
	@JsonIgnoreProperties("user")
	@Relationship(type = "NOTE_S", direction = Relationship.OUTGOING)
	private List<Note_S> notes_s;
	
	public User() {
	}

	public User(String username, String password, String address, String birthdate, String email, String firstname, String lastname, String sex, String picture) {
		this.username = username;
		this.password = password;
		this.address= address;
		this.birthdate=birthdate;
		this.email=email;
		this.firstname=firstname;
		this.lastname=lastname;
		this.sex=sex;
		this.picture=picture;

	}
	
	
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
	
}
