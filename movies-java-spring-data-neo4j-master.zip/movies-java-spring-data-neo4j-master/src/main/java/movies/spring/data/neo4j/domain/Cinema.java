package movies.spring.data.neo4j.domain;

import java.util.List;

import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@NodeEntity
public class Cinema {
	
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private String address;
	private String picture;
	
	@JsonIgnoreProperties("cinema")
	@Relationship(type = "NOTE_C", direction = Relationship.INCOMING)
	private List<Note_C> notes;
	
	public Cinema() {
	}

	public Cinema(String name, String address, String picture) {
		this.name = name;
		this.address = address;
		this.picture= picture;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}
	
	public List<Note_C> getNotes() {
		return notes;
	}

	public void setNotes(List<Note_C> notes) {
		this.notes = notes;
	}

			//effectue la moyenne de toutes les notes du cinéma
			public double getNoteCinema(Cinema cinema) {
				double somme = 0;
				Double liste=null;
				List<Note_C> notes = cinema.getNotes();
				if (notes==null) {
					return -1;
				}
				else {
					for(Note_C note: notes) {
						liste = note.getNote();
						somme = somme + (double) liste;
					}
					double moyenne = somme / (float) notes.size();
					return moyenne;
				}
			}
			
			//retourne la note du cinéma par un utilisateur précis
			public double getNoteUser(Cinema cinema, User user) {
				Double liste=null;
				List<Note_C> notes = cinema.getNotes();
				if (notes==null) {
					return -1;
				}
				else {
					for(Note_C note: notes) {
						User user1 = note.getUser();
						if (user1.getUsername().equals(user.getUsername())) {
							liste = note.getNote();
							return liste;
						}
					}
					return -1;
				}
			}
			
			//retourne le commentaire du cinéma par un utilisateur précis
				public String getCommentUser(Cinema cinema, User user) {
					String liste=null;
					List<Note_C> notes = cinema.getNotes();
					if (notes==null) {
						return " ";
					}
					else {
						for(Note_C note: notes) {
							User user1 = note.getUser();
							if (user1.getUsername().equals(user.getUsername())) {
								liste = note.getComment();
								return liste;
							}
						}
						return " ";
					}
				}


}
