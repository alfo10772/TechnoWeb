package movies.spring.data.neo4j.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Note_S;
import movies.spring.data.neo4j.repositories.Note_SRepository;

@Service
public class Note_SService {
	
	private final Note_SRepository note_sRepository;
	public Note_SService(Note_SRepository note_sRepository) {
		this.note_sRepository = note_sRepository;
	}
	
	@Transactional(readOnly = true)
	public void addNote_S(Note_S note) {
		note_sRepository.save(note);
	}

}
