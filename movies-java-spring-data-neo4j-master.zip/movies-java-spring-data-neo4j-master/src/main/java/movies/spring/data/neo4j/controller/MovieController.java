package movies.spring.data.neo4j.controller;

import java.security.Principal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.News;
import movies.spring.data.neo4j.domain.Note;
import movies.spring.data.neo4j.domain.Person;
import movies.spring.data.neo4j.domain.Role;
import movies.spring.data.neo4j.domain.Serie;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.repositories.MovieRepository;
import movies.spring.data.neo4j.repositories.UserRepository;
import movies.spring.data.neo4j.services.MovieService;
import movies.spring.data.neo4j.services.NewsService;
import movies.spring.data.neo4j.services.NoteService;
import movies.spring.data.neo4j.services.SerieService;
import movies.spring.data.neo4j.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@SessionAttributes("search")
public class MovieController {

	@Autowired
	private MovieService movieService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private NoteService noteService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private SerieService serieService;
	
	
	public MovieController(MovieService movieService) {
		this.movieService = movieService;
	}

    @GetMapping("/")
	public String welcomePage (Model model) {
    	model.addAttribute("search", new Movie());
    	//affiche les news des films
    	List<News> listeNews_film = newsService.findByType("film");
    	model.addAttribute("news_film", listeNews_film);
    	//affiche les news des séries
    	List<News> listeNews_serie = newsService.findByType("serie");
    	model.addAttribute("news_serie", listeNews_serie);
    	//affiche le classement des films
    	List<Movie> movies = movieService.findAll();
    	List<Movie> movies2 = movieService.sortByRateAsc(movies);
    	model.addAttribute("movie_ranking",movies2);
    	//affiche le classement des séries
    	List<Serie> series = serieService.findAll();
		List<Serie> series2 = serieService.sortByRateAsc(series);
    	model.addAttribute("serie_ranking",series2);
		return "welcome";
	}
    
    @GetMapping("/login")
    public String loginPage(Model model) {
        return "connexion";
    }
    
    @GetMapping("/films")
    public String filmPage(Model model) {
    	List<Movie> movie = movieService.findAll();
    	model.addAttribute("movie",movie);
        return "film";
    }
    
    @GetMapping("/infofilm/{id}")
    public String infofilmPage(Model model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Movie movie = movieService.findById(id);
    	model.addAttribute("movie",movie);
    	model.addAttribute("user", user);
    	List<Note> notes = movie.getNotes();
    	model.addAttribute("notes", notes);
    	Note note = new Note(movie,user);
    	model.addAttribute("alert", new Note());
    	model.addAttribute("note", note);
        return "info_film";
    }
    
    @PostMapping(value = "/alert")
    public String addalert(@ModelAttribute Note alert, ModelMap model) {
    	String id2 = alert.getId2();
    	Long id = Long.parseLong(id2);
    	Note note = noteService.findById(id);
    	note.setAlert("true");
    	Movie movie=note.getMovie();
    	model.addAttribute("movie",movie);
        noteService.addNote(note);
		return "alert";
    }
    
    @GetMapping("/contact")
    public String contactPage(Model model, @RequestParam(value="title",required=false) String title) {
        return "contact";
    }
    
    @GetMapping("/ranking")
    public String rankingPage(Model model) {
    	List<Movie> movies = movieService.findAll();
    	List<Movie> movies2 = movieService.sortByRateAsc(movies);
    	model.addAttribute("movie",movies2);
        return "classement";
    }
    
    @GetMapping("/user/dashboard")
    public String dashboardPage(Model model, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	model.addAttribute("user", user);
    	return "user/dashboard";
    }
    
    @GetMapping("/user/information")
    public String informationPage(Model model, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	model.addAttribute("user", user);
        return "/information";
    }
    
    
    @GetMapping("/403")
    public String errorPage(Model model, @RequestParam(value="title",required=false) String title) {
        return "403";
    }
    
    @GetMapping("/search")
    public String search(Model model, @ModelAttribute Movie movie, HttpServletRequest req, HttpServletResponse resp) {
    	Movie movie2=movieService.findByTitle(movie.getTitle());
    	Long id = movie2.getId();
        return infofilmPage(model, id, req, resp);
    }
    
    @GetMapping({"admin/addfilm"})
    public String addPage(Model model) {
    	model.addAttribute("movie", new Movie());
    	model.addAttribute("role", new Role());
    	return "admin/ajout_film";
    }
    
    @PostMapping(value = "/addfilm")
    public String add(@ModelAttribute Movie movie, ModelMap model) {
    	model.addAttribute("title", movie.getTitle());
        model.addAttribute("released", movie.getReleased());
        model.addAttribute("synopsis", movie.getSynopsis());
        model.addAttribute("picture", movie.getPicture());
        model.addAttribute("genre", movie.getGenre());
        model.addAttribute("country", movie.getCountry());
        model.addAttribute("trailer", movie.getTrailer());
        movieService.addMovie(movie);
		return "admin/result";
    }
    
    @PostMapping(value = "/addactor")
    public String addactor(@ModelAttribute Role role, ModelMap model) {
        //movieService.addMovie(movie);
		return "admin/ajout_film";
    }
    
    @GetMapping("admin/deletefilm")
    public String deletePage(Model model) {
    	List<Movie> listemovie = movieService.findAll();
    	model.addAttribute("movie2", new Movie());
    	model.addAttribute("listemovie", listemovie);
    	return "admin/delete_film";
    }
    
    @PostMapping(value = "/deletemovie")
    public String delete(@ModelAttribute Movie movie2, ModelMap model) {
    	String title = movie2.getTitle();
        movieService.deleteMovie(title);
		return "admin/result_delete";
    }
    
    @PostMapping(value = "/infofilm/{id}")
    public String addNote(@ModelAttribute Note note, ModelMap model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Movie movie = movieService.findById(id);
    	model.addAttribute("movie",movie);
    	model.addAttribute("user", user);
    	Note note2 = new Note(movie,user);
    	noteService.addNote(note2);
    	note2.setNote(note.getNote());
    	note2.setComment(note.getComment());
    	note2.setAlert(note.isAlert());
    	String id2=Long.toString(note2.getId());
    	note2.setId2(id2);
        noteService.addNote(note2);
		return "result2";
    }
    
    @GetMapping({"admin/notification"})
    public String notification(Model model) {
    	List<Note> listenote = noteService.findByAlert("true");
    	model.addAttribute("listenote", listenote);
    	model.addAttribute("note2", new Note());
    	return "admin/notification";
    }
    
    @PostMapping(value = "/deletecomment")
    public String deleteComment(@ModelAttribute Note note2, ModelMap model) {
    	String id2 = note2.getId2();
        noteService.deleteNote(id2);
        List<Note> listenote = noteService.findByAlert("true");
    	model.addAttribute("listenote", listenote);
    	model.addAttribute("note2", new Note());
		return "admin/notification";
    }
    
    @PostMapping(value = "/allowcomment")
    public String allowComment(@ModelAttribute Note note2, ModelMap model) {
    	String id2 = note2.getId2();
    	Long id = Long.parseLong(id2);
    	Note note = noteService.findById(id);
    	note.setAlert("false");
        noteService.addNote(note);
        List<Note> listenote = noteService.findByAlert("true");
    	model.addAttribute("listenote", listenote);
    	model.addAttribute("note2", new Note());
		return "admin/notification";
    }
      
}


