package movies.spring.data.neo4j.controller;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.News;
import movies.spring.data.neo4j.domain.Note;
import movies.spring.data.neo4j.domain.Note_S;
import movies.spring.data.neo4j.domain.Serie;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.services.Note_SService;
import movies.spring.data.neo4j.services.SerieService;
import movies.spring.data.neo4j.services.UserService;

@Controller
@SessionAttributes("search")
public class SerieController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private Note_SService note_SService;
	
	@Autowired
	private SerieService serieService;
	
	public SerieController(SerieService serieService) {
		this.serieService = serieService;
	}
	
	@GetMapping("/series")
    public String seriePage(Model model) {
    	List<Serie> serie = serieService.findAll();
    	model.addAttribute("serie",serie);
        return "serie";
    }
	
	@GetMapping("/infoserie/{id}")
    public String infoseriePage(Model model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Serie serie = serieService.findById(id);
    	model.addAttribute("serie",serie);
    	model.addAttribute("user", user);
    	List<Note_S> notes = serie.getNotes();
    	model.addAttribute("notes", notes);
    	Note_S note = new Note_S(serie,user);
    	model.addAttribute("note", note);
        return "info_serie";
    }
	
	@PostMapping(value = "/infoserie/{id}")
    public String addNote(@ModelAttribute Note_S note, ModelMap model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Serie serie = serieService.findById(id);
    	model.addAttribute("serie",serie);
    	model.addAttribute("user", user);
    	Note_S note2 = new Note_S(serie,user);
    	note2.setNote(note.getNote());
    	note2.setComment(note.getComment());
        note_SService.addNote_S(note2);
		return "result3";
    }
	
	@GetMapping("/serie_ranking")
    public String serieRankingPage(Model model) {
		List<Serie> series = serieService.findAll();
		List<Serie> series2 = serieService.sortByRateAsc(series);
    	model.addAttribute("serie",series2);
        return "classement_serie";
    }
	
	@GetMapping("admin/addserie")
    public String addSeriePage(Model model) {
    	model.addAttribute("serie", new Serie());
    	return "admin/ajout_serie";
    }
    
    @PostMapping(value = "/addserie")
    public String addSerie(@ModelAttribute Serie serie, ModelMap model) {
    	model.addAttribute("title", serie.getTitle());
        model.addAttribute("released", serie.getReleased());
        model.addAttribute("picture", serie.getPicture());
        model.addAttribute("genre", serie.getGenre());
        model.addAttribute("country", serie.getCountry());
        model.addAttribute("nbsaison", serie.getNbsaison());
        serieService.addSerie(serie);
		return "admin/result_s";
    }
    
    @GetMapping("admin/deleteserie")
    public String deletePage(Model model) {
    	List<Serie> listeserie = serieService.findAll();
    	model.addAttribute("serie2", new Serie());
    	model.addAttribute("listeserie", listeserie);
    	return "admin/delete_serie";
    }
    
    @PostMapping(value = "/deleteserie")
    public String delete(@ModelAttribute Serie serie2, ModelMap model) {
    	String title = serie2.getTitle();
        serieService.deleteSerie(title);
		return "admin/result_delete";
    }

}
