package movies.spring.data.neo4j.config;

import org.neo4j.ogm.config.Configuration.Builder;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.transaction.Neo4jTransactionManager;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;


@ComponentScan(basePackages = { "movies.spring.data.neo4j.services" })
@ComponentScan(basePackages = { "movies.spring.data.neo4j.config" })
@Configuration
@EnableNeo4jRepositories(basePackages = "movies.spring.data.neo4j.repositories")
public class DatabaseNeo4jConfiguration {
	
	public static final String URL = 
			  System.getenv("NEO4J_URL") != null ? 
			  System.getenv("NEO4J_URL") : "bolt://neo4j:admin@localhost:7687";
			 
			@Bean
			public org.neo4j.ogm.config.Configuration getConfiguration() {
			    org.neo4j.ogm.config.Configuration config = new Builder().uri(URL).build();
			    return config;
			}
			 
			@Bean
			public SessionFactory getSessionFactory() {
			    return new SessionFactory(getConfiguration(), 
			      "movies.spring.data.neo4j.domain");
			}
			 
			@Bean
			public Neo4jTransactionManager transactionManager() {
			    return new Neo4jTransactionManager(getSessionFactory());
			}

}
