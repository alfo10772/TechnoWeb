package movies.spring.data.neo4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;


@SpringBootApplication
@ComponentScan("movies.spring.data.neo4j")
@EnableNeo4jRepositories("movies.spring.data.neo4j.repositories")
public class SampleMovieApplication extends SpringBootServletInitializer {

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SampleMovieApplication.class);
    }
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(SampleMovieApplication.class, args);
    }
}