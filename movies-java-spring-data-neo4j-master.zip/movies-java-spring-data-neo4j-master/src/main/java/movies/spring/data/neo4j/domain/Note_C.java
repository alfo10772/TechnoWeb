package movies.spring.data.neo4j.domain;

import org.neo4j.ogm.annotation.EndNode;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.StartNode;

@RelationshipEntity(type = "NOTE_C")
public class Note_C {
	
	@Id
    @GeneratedValue
	private Long id;
	private Double note;
	private String comment;

	@StartNode
	private User user;

	@EndNode
	private Cinema cinema;

	public Note_C() {
	}

	public Note_C(Cinema cinema, User user) {
		this.cinema = cinema;
		this.user = user;
	}

	public Long getId() {
	    return id;
	}

	public Double getNote() {
	    return note;
	}

	public User getUser() {
	    return user;
	}

	public Cinema getCinema() {
	    return cinema;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public void setNote(Double note) {
		this.note = note;
	}

}
