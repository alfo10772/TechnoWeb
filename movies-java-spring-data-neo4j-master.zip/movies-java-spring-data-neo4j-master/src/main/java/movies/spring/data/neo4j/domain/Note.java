package movies.spring.data.neo4j.domain;


import java.util.ArrayList;
import java.util.List;

import org.neo4j.ogm.annotation.EndNode;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.StartNode;

@RelationshipEntity(type = "NOTE")
public class Note {
	
	@Id
    @GeneratedValue
	private Long id;
	private Double note;
	private String comment;
	private String id2;
	private String alert;

	@StartNode
	private User user;

	@EndNode
	private Movie movie;

	public Note() {
	}
	
	public Note(Movie movie, User user) {
		this.movie = movie;
		this.user = user;
	}

	
	public String getId2() {
		return id2;
	}

	public void setId2(String id2) {
		this.id2 = id2;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
	    return id;
	}

	public Double getNote() {
	    return note;
	}

	public User getUser() {
	    return user;
	}

	public Movie getMovie() {
	    return movie;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public void setNote(Double note) {
		this.note = note;
	}
	
	public String isAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}


}
