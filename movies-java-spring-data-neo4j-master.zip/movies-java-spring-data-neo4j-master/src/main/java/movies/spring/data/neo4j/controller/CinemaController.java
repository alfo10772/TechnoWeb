package movies.spring.data.neo4j.controller;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import movies.spring.data.neo4j.domain.Cinema;
import movies.spring.data.neo4j.domain.Note;
import movies.spring.data.neo4j.domain.Note_C;
import movies.spring.data.neo4j.domain.Note_S;
import movies.spring.data.neo4j.domain.Serie;
import movies.spring.data.neo4j.domain.User;
import movies.spring.data.neo4j.services.CinemaService;
import movies.spring.data.neo4j.services.NoteService;
import movies.spring.data.neo4j.services.Note_CService;
import movies.spring.data.neo4j.services.UserService;

@Controller
@SessionAttributes("search")
public class CinemaController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private Note_CService note_CService;
	
	@Autowired
	private CinemaService cinemaService;
	
	public CinemaController(CinemaService cinemaService) {
		this.cinemaService = cinemaService;
	}
	
	@GetMapping("/cinema")
    public String cinemaPage(Model model) {
    	Collection<Cinema> cinema = cinemaService.findAll();
    	model.addAttribute("cinema",cinema);
        return "cinema";
    }
	
	@GetMapping("/infocine/{id}")
    public String infocinePage(Model model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Cinema cinema = cinemaService.findById(id);
    	model.addAttribute("cinema",cinema);
    	model.addAttribute("user", user);
    	List<Note_C> notes = cinema.getNotes();
    	model.addAttribute("notes", notes);
    	Note_C note = new Note_C(cinema,user);
    	model.addAttribute("note", note);
        return "info_cinema";
    }
	
	@PostMapping(value = "/infocine/{id}")
    public String addNote(@ModelAttribute Note_C note, ModelMap model, @PathVariable Long id, HttpServletRequest req, HttpServletResponse resp) {
    	String username=req.getUserPrincipal().getName();
    	User user= userService.findByUsername(username);
    	Cinema cinema = cinemaService.findById(id);
    	model.addAttribute("cinema",cinema);
    	model.addAttribute("user", user);
    	Note_C note2 = new Note_C(cinema,user);
    	note2.setNote(note.getNote());
    	note2.setComment(note.getComment());
        note_CService.addNote_C(note2);
		return "result4";
    }
	
	@GetMapping("/cinema_ranking")
    public String cinemaRankingPage(Model model) {
		Collection<Cinema> cinema = cinemaService.findAll();
    	model.addAttribute("cinema",cinema);
        return "classement_cinema";
    }
	
	@GetMapping("admin/addcinema")
    public String addCinemaPage(Model model) {
    	model.addAttribute("cinema", new Cinema());
    	return "admin/ajout_cinema";
    }
    
    @PostMapping(value = "/addcinema")
    public String addCinema(@ModelAttribute Cinema cinema, ModelMap model) {
    	model.addAttribute("name", cinema.getName());
        model.addAttribute("address", cinema.getAddress());
        model.addAttribute("picture", cinema.getPicture());
        cinemaService.addCinema(cinema);
		return "admin/result_c";
    }
    
    @GetMapping("admin/deletecinema")
    public String deleteCinemaPage(Model model) {
    	model.addAttribute("cinema", new Cinema());
    	return "admin/delete_cinema";
    }
    
    @PostMapping(value = "/deletecinema")
    public String delete(@ModelAttribute Cinema cinema, ModelMap model) {
    	String name = cinema.getName();
        cinemaService.deleteCinema(name);
		return "admin/result_delete";
    }

}
