package movies.spring.data.neo4j.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import movies.spring.data.neo4j.domain.Movie;
import movies.spring.data.neo4j.domain.Note;
import movies.spring.data.neo4j.repositories.NoteRepository;

@Service
public class NoteService {
	
	private final NoteRepository noteRepository;
	public NoteService(NoteRepository noteRepository) {
		this.noteRepository = noteRepository;
	}
	
	@Transactional(readOnly = true)
	public void addNote(Note note) {
		noteRepository.save(note);
	}
	
	@Transactional(readOnly = true)
    public Note findById(Long id) {
        Optional<Note> result1 = noteRepository.findById(id);
        Note result=result1.get();
        return result;
    }
	
	@Transactional(readOnly = true)
    public List<Note> findByAlert(String alert) {
    	List<Note> result = noteRepository.findByAlert(alert);
        return result;
    }
	
	@Transactional(readOnly = true)
	public void deleteNote(String id2) {
		noteRepository.deleteById2(id2);
	}
}
